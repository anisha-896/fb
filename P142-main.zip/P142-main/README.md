# P142
used python
